import { Frame } from './components/frame/Frame'

import './App.css'

export const App = () => <div className="App">
    <Frame />
</div>